/**
 * SafeShare-AI — Tier 1: Deterministic Heuristic & High-Entropy Scanner
 * Instantly identifies and redacts hard secrets, credentials, PII (KTP, CC, email, phone)
 * with zero perceptible latency (< 2ms).
 */

class HeuristicsRedactor {
  constructor() {
    this.patterns = [
      // 1. Indonesian KTP / NIK (16 digits)
      {
        id: "ID_NIK",
        name: "Indonesian NIK / KTP",
        category: "GOV_ID",
        regex: /\b([1-9][0-9]{15})\b/g,
        replacement: "[REDACTED_NIK]"
      },
      // 1b. US Social Security Number (SSN - 9 digits formatted)
      {
        id: "US_SSN",
        name: "US Social Security Number (SSN)",
        category: "GOV_ID",
        regex: /\b([0-9]{3}-[0-9]{2}-[0-9]{4})\b/g,
        validator: (raw) => this.validateSSN(raw),
        replacement: "[REDACTED_SSN]"
      },
      // 1b-2. US Social Security Number (Raw 9 digits with context)
      {
        id: "US_SSN_RAW",
        name: "US Social Security Number (Raw)",
        category: "GOV_ID",
        regex: /\b((?:(?:social\s+security(?:\s+number)?|ssn)(?:\s+is|\s*[:=\-])?\s*))([0-9]{9})\b/gi,
        validator: (raw) => {
          const digits = raw.replace(/\D/g, "");
          return digits.length === 9 && digits !== "000000000" && !digits.startsWith("000") && !digits.startsWith("666");
        },
        replacement: "$1[REDACTED_SSN]"
      },
      // 1c. US Employer Identification Number (EIN)
      {
        id: "US_EIN",
        name: "US Employer Identification Number (EIN)",
        category: "GOV_ID",
        regex: /\b((?:ein|fein|tax\s+id)\s*[:=\-]?\s*)(\d{2}-\d{7})\b/gi,
        replacement: "$1[REDACTED_EIN]"
      },
      // 1d. ABA Bank Routing Transit Number (9 digits with checksum)
      {
        id: "ABA_ROUTING",
        name: "ABA Bank Routing Transit Number",
        category: "CREDENTIALS",
        regex: /\b((?:(?:routing(?:\s+transit|\s+number)?|aba(?:\s+routing)?)\s*[:=\-]?\s*))(\d{9})\b/gi,
        validator: (raw) => {
          const digits = raw.replace(/\D/g, "");
          const last9 = digits.slice(-9);
          return this.validateRouting(last9);
        },
        replacement: "$1[REDACTED_ROUTING_NUMBER]"
      },
      // 1e. International Bank Account Number (IBAN - ISO 13616)
      {
        id: "IBAN_ACCOUNT",
        name: "International Bank Account Number (IBAN)",
        category: "FINANCIAL",
        regex: /\b([A-Z]{2}\d{2}[A-Z0-9]{11,30})\b/gi,
        validator: (raw) => this.validateIBAN(raw),
        replacement: "[REDACTED_IBAN]"
      },
      // 1f. SWIFT / BIC Code
      {
        id: "SWIFT_BIC",
        name: "SWIFT / BIC Banking Code",
        category: "CREDENTIALS",
        regex: /\b((?:(?:swift(?:\s+code|\s+bic)?|bic)\s*[:=\-]?\s*))([A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?)\b/gi,
        replacement: "$1[REDACTED_SWIFT_BIC]"
      },
      // 2. Credit Card Numbers (13-19 digits with Luhn verification & Fail-Closed Context Fallback)
      {
        id: "CREDIT_CARD",
        name: "Credit Card",
        category: "FINANCIAL",
        regex: /\b(?:\d{4}[ -]?){3}\d{4}\b|\b3[47]\d{2}[ -]\d{6}[ -]\d{5}\b|\b\d{13,19}\b/g,
        validator: (raw, index, text) => {
          if (this.luhnCheck(raw)) return true;
          // Fail-closed fallback: if Luhn fails, but surrounding context explicitly indicates a card number, redact it!
          if (text) {
            const start = Math.max(0, index - 80);
            const end = Math.min(text.length, index + raw.length + 80);
            const window = text.substring(start, end).toLowerCase();
            return /\b(?:card(?:\s+number)?|debit|credit|visa|mastercard|amex|discover|ends\s+in|ending\s+in|pan|cvv|cvc|exp)\b/.test(window);
          }
          return false;
        },
        replacement: "[REDACTED_CARD_NUMBER]"
      },
      // 2b. Card Security Verification Code (CVV, CVC, CID, CSC, CVN - 3-4 digits formatted, spaced, or conversational)
      {
        id: "CARD_SECURITY_CODE",
        name: "Card Security Code (CVV/CVC)",
        category: "FINANCIAL",
        regex: /\b((?:(?:(?:card\s+)?(?:security|verification)\s+(?:code|number|value)|cvv2?|cvc2?|cid|csc|cvn2?|c\s*v\s*v|c\s*v\s*c)(?:\s*\/\s*(?:cvv2?|cvc2?|cid|csc|cvn2?))?)\s*(?:[:=\-~]|is|was|of|equals)?\s*[\[\("']?)([0-9]{3,4}|[0-9]\s+[0-9]\s+[0-9](?:\s+[0-9])?)([\]\)"']?)/gi,
        replacement: (raw) => {
          const m = raw.match(/^([\s\S]*?[\[\("']?)([0-9\s]{3,7})([\]\)"']?)$/);
          if (m) {
            const prefix = m[1].replace(/[\[\("']$/, "");
            return `${prefix}[REDACTED_CVV]`;
          }
          return "[REDACTED_CVV]";
        }
      },
      // 2c. Card Expiration Date (MM/YY or MM/YYYY with anchor)
      {
        id: "CARD_EXPIRY_DATE",
        name: "Card Expiration Date",
        category: "FINANCIAL",
        regex: /\b((?:(?:card\s+)?(?:exp(?:iration)?|expiry)(?:\s+date)?)\s*[:=\-]?\s*)((?:0[1-9]|1[0-2])[\/-](?:20)?\d{2})\b/gi,
        replacement: "$1[REDACTED_CARD_EXPIRY]"
      },
      // 2d. Universal Record, Account, Policy, Loan, & Booking Identifiers (Cross-Domain)
      {
        id: "UNIVERSAL_RECORD_IDENTIFIER",
        name: "Account / Record Identifier",
        category: "FINANCIAL",
        regex: /\b((?:(?:checking|savings|bank|loan|credit|mortgage|deposit)\s+account(?:\s+number)?|(?:(?:account|acct|loan|policy|claim|member|group|booking|pnr|e-?ticket|record|case|docket|invoice|order|tracking)(?:\s+(?:#|id|number|no\.?|code|reference|\bref\b))?)|(?:sofi|wf|wells\s+fargo|chase|citi|bofa|aetna|cigna|united|metlife)\s+(?:account|loan|policy))\s*(?:[:=\-]|is)?\s*#?)([A-Za-z0-9]{1,8}[-_/][A-Za-z0-9_-]{4,24}|1Z[0-9A-Z]{16}|[0-9]{6,18}|(?=[A-Za-z0-9]*\d)[A-Za-z0-9]{5,12})\b/gi,
        validator: (raw, index, text) => {
          const clean = raw.trim();
          if (/^(?:active|pending|closed|open|true|false|none|null|undefined|ready)$/i.test(clean)) return false;
          return true;
        },
        replacement: "$1[REDACTED_RECORD_ID]"
      },
      // 2e. Standalone Bank Account Prefix Identifiers (e.g. WF-990218374, SOFI-99821174, AETNA-8849201)
      {
        id: "PREFIXED_BANK_LOAN_ID",
        name: "Bank / Loan / Policy ID",
        category: "FINANCIAL",
        regex: /\b((?:(?:from|to|via|on|in|#|account|acct|loan|policy|claim|ref|rekening)\s*(?:[:=\-]|is)?\s*)?)([A-Z]{2,6}-\d{6,14})\b/g,
        validator: (raw, index, text) => {
          const m = raw.match(/([A-Z]{2,6})-(\d{6,14})/);
          if (!m) return false;
          const prefix = m[1].toUpperCase();
          const technicalExclusions = ["CVE", "RFC", "ISO", "IEEE", "HTTP", "HTTPS", "UTF", "UTC", "SHA", "MD", "SONNET", "OPUS", "HAIKU", "LLAMA", "GEMINI", "CLAUDE", "PORT"];
          if (technicalExclusions.includes(prefix)) return false;

          const knownInstitutions = ["WF", "SOFI", "CHASE", "CITI", "BOFA", "PNC", "ALLY", "AETNA", "CIGNA", "METLIFE", "USAA", "TD", "BCA", "BRI", "BNI", "MANDIRI", "AMEX", "DISCOVER"];
          if (knownInstitutions.includes(prefix)) return true;

          if (text) {
            const start = Math.max(0, index - 80);
            const end = Math.min(text.length, index + raw.length + 80);
            const window = text.substring(start, end).toLowerCase();
            return /\b(?:account|acct|loan|checking|savings|balance|bank|policy|claim|deposit|statement|bill|rekening|pinjaman|member)\b/.test(window);
          }
          return false;
        },
        replacement: "$1[REDACTED_ACCOUNT_ID]"
      },
      // 2f. Card Ending In Last 4 Digits
      {
        id: "CARD_LAST_FOUR",
        name: "Card Last Four Digits",
        category: "FINANCIAL",
        regex: /\b((?:(?:(?:(?:debit|credit)\s+)?(?:card|account))\s*[:=\-]?\s*)?(?:ends|ending)\s+in\s*)([0-9]{4})\b/gi,
        validator: (raw, index, text) => {
          if (text) {
            const start = Math.max(0, index - 40);
            const before = text.substring(start, index).toLowerCase();
            if (/\b(?:year|quarter|month|period|semester|fiscal|week|day)\s*$/i.test(before)) {
              return false;
            }
          }
          return true;
        },
        replacement: "$1[REDACTED_CARD_LAST_4]"
      },
      // 3. Email Addresses (Standard and Defanged [at]/[dot]/(at)/(dot))
      {
        id: "EMAIL",
        name: "Email Address",
        category: "PROFILE",
        regex: /\b[A-Za-z0-9._%+-]+(?:\s*@\s*|\s*\[at\]\s*|\s*\(at\)\s*)[A-Za-z0-9.-]+(?:\s*\.\s*|\s*\[dot\]\s*|\s*\(dot\)\s*)[A-Za-z]{2,}\b/gi,
        replacement: (match, index, context) => `[user_${Math.abs(this.hashString(match)) % 1000}@protected.local]`
      },
      // 4. Phone Numbers (ID: +62/08..., US/International with Toll-Free Hotline Protection)
      {
        id: "PHONE",
        name: "Phone Number",
        category: "PROFILE",
        regex: /(?:\+?62|0)8[1-9][0-9]{7,10}\b|(?<=^|[\s,;:(])(?:\+?1[-.\s]?)?\(?[2-9]\d{2}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g,
        validator: (raw, index, text) => {
          // If it's a toll-free number (800, 888, 877, 866, 855, 844, 833) in corporate/support context, preserve it!
          const digits = raw.replace(/\D/g, "");
          const isTollFree = /^(?:1)?(?:800|888|877|866|855|844|833)/.test(digits);
          if (isTollFree && text) {
            const start = Math.max(0, index - 80);
            const window = text.substring(start, Math.min(text.length, index + raw.length + 40)).toLowerCase();
            if (/\b(?:call|support|service|official|hotline|helpdesk|contact|toll-?free|bank|wells\s+fargo|customer|help|amazon|sofi|aetna|cigna|number\s+on\s+the\s+back)\b/.test(window)) {
              return false; // Preserve public business support hotline
            }
          }
          return true; // Redact personal phone numbers
        },
        replacement: "[REDACTED_PHONE]"
      },
      // 5. OpenAI API Keys (Legacy & Project keys)
      {
        id: "OPENAI_KEY",
        name: "OpenAI Secret Key",
        category: "CREDENTIALS",
        regex: /\bsk-(?:proj-)?[A-Za-z0-9_-]{32,80}\b/g,
        replacement: "sk-dummy-test-key-placeholder"
      },
      // 5a-1. Anthropic API Key (Claude)
      {
        id: "ANTHROPIC_KEY",
        name: "Anthropic Claude API Key",
        category: "CREDENTIALS",
        regex: /\bsk-ant-api03-[A-Za-z0-9_-]{80,110}\b/g,
        replacement: "sk-ant-api03-dummyPlaceholderKeyForTesting00000"
      },
      // 5a-2. Google Cloud / Maps API Key
      {
        id: "GOOGLE_API_KEY",
        name: "Google Cloud / Maps API Key",
        category: "CREDENTIALS",
        regex: /\bAIzaSy[A-Za-z0-9_-]{30,35}\b/g,
        replacement: "AIzaSyDummyPlaceholderGoogleApiKey0000"
      },
      // 5a-3. Hugging Face Access Token
      {
        id: "HUGGINGFACE_TOKEN",
        name: "Hugging Face Access Token",
        category: "CREDENTIALS",
        regex: /\bhf_[A-Za-z0-9]{34,40}\b/g,
        replacement: "hf_dummyPlaceholderHuggingFaceToken000"
      },
      // 5a-4. NPM Automation / Publish Access Token
      {
        id: "NPM_TOKEN",
        name: "NPM Access Token",
        category: "CREDENTIALS",
        regex: /\bnpm_[A-Za-z0-9]{36,50}\b/g,
        replacement: "npm_dummyPlaceholderNpmTokenForTesting0000"
      },
      // 5a-5. GitLab Personal Access Token
      {
        id: "GITLAB_TOKEN",
        name: "GitLab Personal Access Token",
        category: "CREDENTIALS",
        regex: /\bglpat-[A-Za-z0-9_-]{20,30}\b/g,
        replacement: "glpat-dummyPlaceholderGitLabToken00000"
      },
      // 5a-6. WireGuard VPN Private Key
      {
        id: "WIREGUARD_PRIVATE_KEY",
        name: "WireGuard VPN Private Key",
        category: "CREDENTIALS",
        regex: /(\bPrivateKey\s*=\s*)([A-Za-z0-9+/]{42,45}=)/g,
        replacement: "$1[REDACTED_WIREGUARD_PRIVATE_KEY]"
      },
      // 5b. Stripe Production & Restricted Keys (sk_live_, rk_live_, etc.)
      {
        id: "STRIPE_KEY",
        name: "Stripe Secret Key",
        category: "CREDENTIALS",
        regex: /\b(?:sk|rk)_(?:live|test)_[a-zA-Z0-9]{20,99}\b/g,
        replacement: "[REDACTED_STRIPE_KEY]"
      },
      // 5c. Slack Webhook URLs
      {
        id: "SLACK_WEBHOOK",
        name: "Slack Incoming Webhook",
        category: "CREDENTIALS",
        regex: /\bhttps:\/\/hooks\.slack\.com\/services\/T[a-zA-Z0-9_]+\/B[a-zA-Z0-9_]+\/[a-zA-Z0-9_]+\b/g,
        replacement: "[REDACTED_SLACK_WEBHOOK]"
      },
      // 5d. Ethereum / EVM Wallet Address (0x...)
      {
        id: "EVM_CRYPTO_WALLET",
        name: "Ethereum EVM Wallet Address",
        category: "CREDENTIALS",
        regex: /\b(0x[a-fA-F0-9]{40})\b/g,
        replacement: "[REDACTED_CRYPTO_WALLET]"
      },
      // 5d-2. Bitcoin BTC Wallet Address (Bech32 bc1 & Base58 Legacy 1 or 3)
      {
        id: "BITCOIN_WALLET",
        name: "Bitcoin BTC Wallet Address",
        category: "CREDENTIALS",
        regex: /\b(bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b/g,
        replacement: "[REDACTED_CRYPTO_WALLET]"
      },
      // 5d-3. Solana SOL Wallet Address (Base58, 32-44 chars)
      {
        id: "SOLANA_WALLET",
        name: "Solana SOL Wallet Address",
        category: "CREDENTIALS",
        regex: /\b([1-9A-HJ-NP-Za-km-z]{32,44})\b/g,
        validator: (raw, index, text) => {
          if (!text) return false;
          const start = Math.max(0, index - 80);
          const end = Math.min(text.length, index + raw.length + 80);
          const window = text.substring(start, end).toLowerCase();
          return /\b(?:sol|solana|phantom|wallet|address|dompet|transfer|crypto|token|pubkey)\b/.test(window);
        },
        replacement: "[REDACTED_CRYPTO_WALLET]"
      },
      // 5e. BIP-39 12/24-Word Recovery Mnemonic Seed Phrase
      {
        id: "BIP39_SEED_PHRASE",
        name: "BIP-39 Mnemonic Recovery Seed Phrase",
        category: "CREDENTIALS",
        regex: /(\b(?:seed|mnemonic|recovery(?:\s+phrase)?|bip-?39)[^:\n\r]*[:=\-]?\s*)([a-z]{3,12}(?:[ \t]+[a-z]{3,12}){11,23})\b/gi,
        replacement: "$1[REDACTED_MNEMONIC_SEED_PHRASE]"
      },
      // 5f. Linux /etc/shadow Password Hashes
      {
        id: "LINUX_SHADOW_HASH",
        name: "Linux Shadow Password Hash",
        category: "CREDENTIALS",
        regex: /\$(?:1|2[aby]?|5|6)\$[a-zA-Z0-9_$./=-]+\$[a-zA-Z0-9./]{16,86}/g,
        replacement: "$6$rounds=4096$[REDACTED_PASSWORD_HASH]"
      },
      // 6. GitHub Personal Access Tokens
      {
        id: "GITHUB_TOKEN",
        name: "GitHub Access Token",
        category: "CREDENTIALS",
        regex: /\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,255}\b/g,
        replacement: "ghp_dummyPlaceholderTokenForTesting00000"
      },
      // 7. AWS Access Key IDs
      {
        id: "AWS_KEY",
        name: "AWS Access Key",
        category: "CREDENTIALS",
        regex: /\b(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}\b/g,
        replacement: "AKIAIOSFODNN7EXAMPLE"
      },
      // 8. JSON Web Tokens (JWT)
      {
        id: "JWT",
        name: "JSON Web Token",
        category: "CREDENTIALS",
        regex: /\beyJ[A-Za-z0-9-_=]+\.eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_.+/=]*\b/g,
        replacement: "[REDACTED_JWT_TOKEN]"
      },
      // 9. RSA/SSH/EC Private Keys (PEM blocks)
      {
        id: "PEM_PRIVATE_KEY",
        name: "Private Key Block",
        category: "CREDENTIALS",
        regex: /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
        replacement: "-----BEGIN PRIVATE KEY-----\n[REDACTED_PRIVATE_KEY_BLOCK]\n-----END PRIVATE KEY-----"
      },
      // 10. Database Connection Strings (Postgres, MySQL, Mongo, Redis with passwords, supporting URL-encoded schemes)
      {
        id: "DATABASE_URI",
        name: "Database Credentials URI",
        category: "CREDENTIALS",
        regex: /\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis)(?::\/\/|%3A%2F%2F)[^:\s]+:[^@\s]+@[^\s/:]+(?::\d+)?\/[^\s]*/gi,
        replacement: "postgresql://postgres:placeholder_password@localhost:5432/sandbox_db"
      },
      // 10b. CLI Curl / Basic Auth Credentials (-u user:password)
      {
        id: "CLI_BASIC_AUTH",
        name: "CLI Basic Auth Credentials",
        category: "CREDENTIALS",
        regex: /(\b(?:curl[^\n]*?-u\s+|-u\s+))([A-Za-z0-9._-]+:[^\s]+)/gi,
        replacement: "$1[user]:[password]"
      },
      // 10c. HTTP Basic Authorization Header (Base64)
      {
        id: "HTTP_BASIC_AUTH_HEADER",
        name: "HTTP Basic Authorization Header",
        category: "CREDENTIALS",
        regex: /(\bAuthorization:\s*Basic\s+)([A-Za-z0-9+/=]{16,})/gi,
        replacement: "$1[REDACTED_BASE64_CREDENTIALS]"
      },
      // 10d. Environment Variables Secrets (AWS Secret Key, DB Passwords, etc.)
      {
        id: "ENV_CONFIG_SECRET",
        name: "Environment Variable Secret",
        category: "CREDENTIALS",
        regex: /\b((?:DATABASE_URL|DB_URL|AWS_SECRET_ACCESS_KEY|SECRET_ACCESS_KEY|API_SECRET|DB_PASS(?:WORD)?|PASSWORD|SECRET_KEY|AUTH_TOKEN|PRIVATE_KEY|APP_SECRET|CLIENT_SECRET)\s*=\s*)([^\s\r\n'"]{8,120})/gi,
        replacement: "$1[REDACTED_SECRET]"
      },
      // 10e. YAML Configuration Password & Secret Block
      {
        id: "YAML_CONFIG_SECRET",
        name: "YAML Config Secret Key",
        category: "CREDENTIALS",
        regex: /(^[ \t]*(?:password|passwd|secret|token|api_key|auth_token)\s*:\s*)([^\s\r\n'"]{6,120})/gmi,
        replacement: "$1[REDACTED_SECRET]"
      },
      // 11. Physical Home / Street Address (Expanded for KTP/Domisili and structured forms)
      {
        id: "ADDRESS_ID",
        name: "Physical Home/Street Address",
        category: "PROFILE",
        regex: /\b(?:(?:alamat(?:\s+(?:ktp|domisili|saya|tinggal|rumah))?|(?:saya\s+)?tinggal\s+di|rumah(?:\s+saya)?\s+di|domisili(?:\s+di)?)(?:\s+di|\s+adalah|\s*:)?\s*)([A-Za-z0-9\s.,\/-]+?)(?=\s*(?:nomor\s+telfon|nomor\s+hp|no\s+hp|no\s+telp|telfon|telepon|phone|email|nik|nim|npwp|paspor|passport|sim|bpjs|gaji|[\r\n]|$))/gi,
        validator: (raw) => {
          const physicalMarkers = /\b(?:jalan|jl\.?|gang|gg\.?|kampung|kp\.?|komplek|perumahan|dusun|desa|kelurahan|kecamatan|rt\s*\d+|rw\s*\d+|no(?:mor)?\s*\d+|blok\s*[a-z0-9]+)\b/i;
          const computingExclusions = /\b(?:memori|memory|fungsi|function|pointer|register|symbol|instruksi|instruction|hex|libc|gdb|binary|assembly|setcontext|ip|mac|url|socket)\b|&[a-zA-Z_]|0x[0-9a-fA-F]+/i;
          return physicalMarkers.test(raw) && !computingExclusions.test(raw);
        },
        replacement: "alamat di [REDACTED_ADDRESS] "
      },
      // 11b. English Residential / Shipping Address (US / UK Street & Postal Formats)
      {
        id: "ENGLISH_PHYSICAL_ADDRESS",
        name: "US/UK Physical Street Address",
        category: "PROFILE",
        regex: /\b((?:(?:residential|shipping|mailing|home|street|billing)\s+)?address\s*[:=\-]?\s*(?:to\s+my\s+residential\s+address\s*:\s*)?|(?:(?:shipping|deliver(?:y|ing)?|ship|send|sent)\s+to\s+))((?:(?:Flat|Unit|Apt|Apartment|Suite)\s+\d+[a-zA-Z]?,?\s*(?:[0-9]{1,5}\s+)?|[0-9]{1,5}\s+)[A-Za-z0-9\s.,\/-]+?\b(?:Street|St|Avenue|Ave|Boulevard|Blvd|Road|Rd|Drive|Dr|Lane|Ln|Way|Court|Ct|Terrace|Ter|Place|Pl|Circle|Cir|Parkway|Pkwy)\b(?:[A-Za-z0-9\s.,\/-]*?(?:[A-Z]{2}\s+\d{5}(?:-\d{4})?|[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}))?)/gi,
        replacement: "$1[REDACTED_ADDRESS]"
      },
      // 12. Indonesian Tax ID (NPWP - 15/16 digits formatted or raw)
      {
        id: "ID_NPWP",
        name: "Indonesian Tax ID (NPWP)",
        category: "GOV_ID",
        regex: /\b((?:npwp(?:\s+pribadi|\s+badan)?\s*[:=\-]?\s*)?)(\d{2}\.\d{3}\.\d{3}\.\d{1}-\d{3}\.\d{3})\b/gi,
        replacement: "$1[REDACTED_NPWP]"
      },
      // 13. Indonesian & International Passport (Paspor RI / US / UK)
      {
        id: "PASSPORT_RI",
        name: "Passport Number",
        category: "GOV_ID",
        regex: /\b((?:(?:nomor\s+)?paspor(?:\s+ri)?|(?:us|uk|international)?\s*passport(?:\s+number)?)(?:\s+is|\s+was|\s+saya|\s+ku|\s+Anda|\s+kamu|\s*[:=\-])?\s*)([A-Z]\d{7,8}|\d{9})\b/gi,
        replacement: "$1[REDACTED_PASSPORT]"
      },
      // 14. BPJS Kesehatan & Ketenagakerjaan (11-13 digits)
      {
        id: "ID_BPJS",
        name: "BPJS Health & Employment ID",
        category: "GOV_ID",
        regex: /\b((?:(?:nomor\s+)?bpjs(?:\s+kesehatan|\s+ketenagakerjaan|\s+tk)?)\s*[:=\-]?\s*)(\d{11,13})\b/gi,
        replacement: "$1[REDACTED_BPJS]"
      },
      // 15. Indonesian Driving License (SIM A/C - 12 digits)
      {
        id: "ID_SIM",
        name: "Indonesian Driver License (SIM)",
        category: "GOV_ID",
        regex: /\b((?:(?:nomor\s+)?sim(?:\s+[a-c])?)\s*[:=\-]?\s*)(\d{12})\b/gi,
        replacement: "$1[REDACTED_SIM]"
      },
      // 16. Academic & Student Identification (NIM, NPM, NRP, Student ID)
      {
        id: "STUDENT_ID",
        name: "Student ID / Academic NIM",
        category: "GOV_ID",
        regex: /\b((?:nim|npm|nrp|no\.?\s*mahasiswa|student\s*id|nomor\s*induk\s*mahasiswa)\s*[:=\-]?\s*)([0-9]{8,14})\b/gi,
        replacement: "$1[REDACTED_NIM]"
      },
      // 16b. UK National Insurance Number (NINO)
      {
        id: "UK_NINO",
        name: "UK National Insurance Number (NINO)",
        category: "GOV_ID",
        regex: /\b((?:(?:nino|national\s+insurance(?:\s+number)?)\s*[:=\-~]?\s*|(?<=\b)))([A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z]\s*\d{2}\s*\d{2}\s*\d{2}\s*[A-D])\b/gi,
        replacement: "$1[REDACTED_NINO]"
      },
      // 16c. Canadian Social Insurance Number (SIN)
      {
        id: "CA_SIN",
        name: "Canadian Social Insurance Number (SIN)",
        category: "GOV_ID",
        regex: /\b((?:(?:sin|social\s+insurance(?:\s+number)?)\s*[:=\-~]?\s*|(?<=\b)))(\d{3}[-\s]\d{3}[-\s]\d{3})\b/gi,
        validator: (raw, index, text) => {
          if (!text) return true;
          const window = text.substring(Math.max(0, index - 60), Math.min(text.length, index + raw.length + 60)).toLowerCase();
          return /\b(?:sin|social\s+insurance|cra|canada|canadian|tax|resident)\b/.test(window);
        },
        replacement: "$1[REDACTED_SIN]"
      },
      // 16d. Indian Aadhaar Number (12 digits)
      {
        id: "IN_AADHAAR",
        name: "Indian Aadhaar Number",
        category: "GOV_ID",
        regex: /\b((?:(?:aadhaar|uidai|adhaar)(?:\s+(?:number|card))?\s*[:=\-~]?\s*|(?<=\b)))([2-9]\d{3}[-\s]\d{4}[-\s]\d{4})\b/gi,
        validator: (raw, index, text) => {
          if (!text) return true;
          const window = text.substring(Math.max(0, index - 60), Math.min(text.length, index + raw.length + 60)).toLowerCase();
          return /\b(?:aadhaar|uidai|adhaar|india|indian|resident|citizen|kyc)\b/.test(window);
        },
        replacement: "$1[REDACTED_AADHAAR]"
      },
      // 16e. Indian Permanent Account Number (PAN)
      {
        id: "IN_PAN",
        name: "Indian PAN Card Number",
        category: "GOV_ID",
        regex: /\b((?:(?:pan(?:\s+(?:card|number))?)\s*[:=\-~]?\s*|(?<=\b)))([A-Z]{5}[0-9]{4}[A-Z])\b/gi,
        validator: (raw, index, text) => {
          if (!text) return true;
          const window = text.substring(Math.max(0, index - 60), Math.min(text.length, index + raw.length + 60)).toLowerCase();
          return /\b(?:pan|income\s+tax|tax\s+filing|kyc|india|indian)\b/.test(window);
        },
        replacement: "$1[REDACTED_PAN]"
      },
      // 16f. Singapore NRIC / FIN
      {
        id: "SG_NRIC",
        name: "Singapore NRIC / FIN",
        category: "GOV_ID",
        regex: /\b((?:(?:nric|fin)(?:\s+(?:number|id))?\s*[:=\-~]?\s*|(?<=\b)))([STFGMS]\d{7}[A-Z])\b/gi,
        replacement: "$1[REDACTED_NRIC]"
      },
      // 16g. Brazilian CPF
      {
        id: "BR_CPF",
        name: "Brazilian CPF",
        category: "GOV_ID",
        regex: /\b((?:(?:cpf)\s*[:=\-~]?\s*|(?<=\b)))(\d{3}\.\d{3}\.\d{3}-\d{2})\b/gi,
        replacement: "$1[REDACTED_CPF]"
      },
      // 16h. Spanish DNI / NIE
      {
        id: "ES_DNI",
        name: "Spanish DNI / NIE",
        category: "GOV_ID",
        regex: /\b((?:(?:dni|nie)\s*[:=\-~]?\s*|(?<=\b)))(\d{8}[A-HJ-NP-TV-Z]|[XYZ]\d{7}[A-HJ-NP-TV-Z])\b/gi,
        replacement: "$1[REDACTED_DNI]"
      },
      // 16i. Italian Codice Fiscale
      {
        id: "IT_CODICE_FISCALE",
        name: "Italian Codice Fiscale",
        category: "GOV_ID",
        regex: /\b((?:(?:codice\s+fiscale)\s*[:=\-~]?\s*|(?<=\b)))([A-Z]{6}\d{2}[A-EHLMPR-T]\d{2}[A-Z]\d{3}[A-Z])\b/gi,
        replacement: "$1[REDACTED_TAX_ID]"
      },
      // 16j. UK Bank Sort Code (6 digits)
      {
        id: "UK_SORT_CODE",
        name: "UK Bank Sort Code",
        category: "CREDENTIALS",
        regex: /\b((?:(?:sort\s+code)\s*[:=\-~]?\s*))(\d{2}[-\s]\d{2}[-\s]\d{2})\b/gi,
        replacement: "$1[REDACTED_SORT_CODE]"
      },
      // 16k. Indian IFSC Banking Code
      {
        id: "IN_IFSC",
        name: "Indian IFSC Code",
        category: "CREDENTIALS",
        regex: /\b((?:(?:ifsc(?:\s+code)?)\s*[:=\-~]?\s*))([A-Z]{4}0[A-Z0-9]{6})\b/gi,
        replacement: "$1[REDACTED_IFSC]"
      },
      // 16l. Australian BSB Code
      {
        id: "AU_BSB",
        name: "Australian BSB Banking Code",
        category: "CREDENTIALS",
        regex: /\b((?:(?:bsb(?:\s+number|\s+code)?)\s*[:=\-~]?\s*))(\d{3}[-\s]\d{3})\b/gi,
        replacement: "$1[REDACTED_BSB]"
      },
      // 16m. UK NHS Number (Healthcare Patient ID)
      {
        id: "UK_NHS",
        name: "UK NHS Number",
        category: "HEALTH",
        regex: /\b((?:(?:nhs(?:\s+number)?)\s*[:=\-~]?\s*))(\d{3}[-\s]?\d{3}[-\s]?\d{4})\b/gi,
        replacement: "$1[REDACTED_HEALTH_ID]"
      },
      // 16n. US Hospital Medical Record Number (MRN)
      {
        id: "US_MRN",
        name: "Medical Record Number (MRN)",
        category: "HEALTH",
        regex: /\b((?:(?:mrn|medical\s+record(?:\s+number)?|patient(?:\s+record)?\s+id)\s*[:=\-~]?\s*))([A-Za-z0-9]{6,12})\b/gi,
        replacement: "$1[REDACTED_HEALTH_ID]"
      },
      // 16o. GitHub Fine-Grained Personal Access Token
      {
        id: "GITHUB_FINE_GRAINED",
        name: "GitHub Fine-Grained Token",
        category: "CREDENTIALS",
        regex: /\b(github_pat_[A-Za-z0-9_]{60,100})\b/g,
        replacement: "[REDACTED_GITHUB_TOKEN]"
      },
      // 16p. Telegram Bot API Token
      {
        id: "TELEGRAM_BOT_TOKEN",
        name: "Telegram Bot API Token",
        category: "CREDENTIALS",
        regex: /\b(\d{8,10}:[A-Za-z0-9_-]{35})\b/g,
        replacement: "[REDACTED_TELEGRAM_TOKEN]"
      },
      // 16q. Date of Birth (DoB) - International & Indonesian Formats
      {
        id: "ID_DOB",
        name: "Date of Birth (DoB)",
        category: "PROFILE",
        regex: /\b((?:(?:date\s+of\s+birth|dob|born\s+on|birth\s*date|tanggal\s+lahir|tgl\s+lahir|lahir(?:\s+tanggal|\s+pada)?)\s*(?:is|\s*[:=\-~])?\s*))(\d{4}[-/.]\d{2}[-/.]\d{2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4}|(?:(?:\d{1,2}\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)|Januari|Februari|Maret|April|Mei|Juni|Juli|Agustus|September|Oktober|November|Desember))|(?:(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember))\s+\d{1,2}(?:th|st|nd|rd)?)),?\s+\d{4})\b/gi,
        replacement: "$1[REDACTED_DOB]"
      },
      // 16r. Mother's Maiden Name (Knowledge-Based Authentication Question)
      {
        id: "ID_MOTHER_MAIDEN",
        name: "Mother's Maiden Name",
        category: "PROFILE",
        regex: /\b((?:(?:mother(?:\x27?s)?\s+maiden\s+name|nama\s+ibu\s+kandung)(?:\s+saya)?(?:\s+adalah|\s+is|\s*[:=\-~])?\s*))([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,3}?)(?=\s+(?:and\b|is\b|born\b|living\b|from\b|was\b|di\b|dan\b|pada\b)|[,.;\n\r]|$)/gi,
        replacement: "$1[REDACTED_FAMILY_NAME]"
      },
      // 16s. Vehicle License Plates (Indonesian Police Numbers e.g. B 1829 XYZ, D 1234 AB)
      {
        id: "ID_PLATE_RI",
        name: "Indonesian Vehicle License Plate",
        category: "PROFILE",
        regex: /\b((?:(?:plat(?:\s+nomor|\s+mobil|\s+motor)?|nomor\s+polisi|nopol)\s*[:=\-~]?\s*|(?<=\b)))([A-Z]{1,2}\s+\d{1,4}\s+[A-Z]{1,3})\b/gi,
        validator: (raw) => {
          const m = raw.trim().split(/\s+/);
          if (m.length !== 3) return false;
          const validPrefixes = new Set([
            "A","B","D","E","F","G","H","K","L","M","N","P","R","S","T",
            "AA","AB","AD","AE","AG","BA","BB","BD","BE","BG","BH","BK",
            "BL","BM","BN","BP","DA","KB","KH","KT","KU","DB","DC","DD",
            "DE","DG","DH","DK","DM","DN","DT","DW","PA","PB"
          ]);
          return validPrefixes.has(m[0].toUpperCase());
        },
        replacement: "$1[REDACTED_LICENSE_PLATE]"
      },
      // 16t. US/International Vehicle License Plate
      {
        id: "US_PLATE",
        name: "US/International License Plate",
        category: "PROFILE",
        regex: /\b((?:(?:license\s+plate|plate(?:\s+number)?)\s*[:=\-~]?(?:\s*is)?\s*))([A-Z0-9]{5,8})\b/gi,
        replacement: "$1[REDACTED_LICENSE_PLATE]"
      },
      // 16u. Vehicle Identification Number (VIN - 17 alphanumeric ISO 3779 standard)
      {
        id: "VEHICLE_VIN",
        name: "Vehicle Identification Number (VIN)",
        category: "PROFILE",
        regex: /\b((?:(?:vin|vehicle\s+identification(?:\s+number)?|nomor\s+rangka)\s*(?:is|\s*[:=\-~])?\s*))([A-HJ-NPR-Z0-9]{17})\b/gi,
        replacement: "$1[REDACTED_VIN]"
      },
      // 16v. Mobile Device IMEI (15-digit identifier with context)
      {
        id: "DEVICE_IMEI",
        name: "Mobile Device IMEI",
        category: "PROFILE",
        regex: /\b((?:(?:imei|device\s+id)\s*(?:is|\s*[:=\-~])?\s*))(\d{15})\b/gi,
        replacement: "$1[REDACTED_IMEI]"
      },
      // 16w. Network IPv6 Address (Full, Compressed, Local)
      {
        id: "NETWORK_IPV6",
        name: "IPv6 Network Address",
        category: "SYSTEM",
        regex: /\b(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,})\b/gi,
        validator: (raw) => {
          // Exclude simple CSS or code structures
          return raw.includes(":") && raw.length >= 7;
        },
        replacement: "[REDACTED_IPV6]"
      },
      // 16x. Hardware MAC Address (Standard Colon, Dash, or Dot formats)
      {
        id: "HARDWARE_MAC",
        name: "Hardware MAC Address",
        category: "SYSTEM",
        regex: /\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b|\b(?:[0-9A-Fa-f]{4}\.){2}[0-9A-Fa-f]{4}\b/gi,
        replacement: "[REDACTED_MAC_ADDRESS]"
      },
      // 16y. Precision GPS Coordinates (Latitude & Longitude)
      {
        id: "GPS_COORDINATES",
        name: "Precision GPS Coordinates",
        category: "PROFILE",
        regex: /\b(?:(?:coordinates|coords|lat(?:itude)?|lokasi\s+gps)\s*[:=\-~]?\s*[-+]?\d{1,3}\.\d{4,8}\s*[,;\s]\s*(?:long(?:itude)?|lng)?\s*[:=\-~]?\s*[-+]?\d{1,3}\.\d{4,8}|lat\s*[-+]?\d{1,3}\.\d{4,8}\s*,\s*long\s*[-+]?\d{1,3}\.\d{4,8})\b/gi,
        replacement: "[REDACTED_GPS_COORDINATES]"
      },
      // 16z-1. Chinese Resident Identity Card (18 digits)
      {
        id: "CN_CITIZEN_ID",
        name: "Chinese National ID",
        category: "GOV_ID",
        regex: /\b((?:(?:citizen\s+id|resident\s+id|id\s+card|shenfenzheng)\s*[:=\-~]?\s*|(?<=\b)))(\d{6}(?:18|19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx])\b/gi,
        validator: (raw, index, text) => {
          if (!text) return true;
          const window = text.substring(Math.max(0, index - 60), Math.min(text.length, index + raw.length + 60)).toLowerCase();
          return /\b(?:china|chinese|resident|citizen|shenfenzheng|prc|beijing|shanghai|shenzhen)\b/.test(window);
        },
        replacement: "$1[REDACTED_NATIONAL_ID]"
      },
      // 16z-2. Korean Resident Registration Number (RRN - 13 digits YYMMDD-1XXXXXX)
      {
        id: "KR_RRN",
        name: "Korean Resident Registration Number",
        category: "GOV_ID",
        regex: /\b((?:(?:rrn|resident\s+registration(?:\s+number)?)\s*[:=\-~]?\s*|(?<=\b)))(\d{6}[-\s][1-4]\d{6})\b/gi,
        replacement: "$1[REDACTED_NATIONAL_ID]"
      },
      // 16z-3. Japanese My Number (Individual Number - 12 digits)
      {
        id: "JP_MY_NUMBER",
        name: "Japanese My Number",
        category: "GOV_ID",
        regex: /\b((?:(?:my\s+number|individual\s+number)(?:\s*\([^)]*\))?\s*(?:is|\s*[:=\-~])?\s*))(\d{4}\s*\d{4}\s*\d{4})\b/gi,
        replacement: "$1[REDACTED_NATIONAL_ID]"
      },
      // 16z-4. Australian Tax File Number (TFN - 8-9 digits)
      {
        id: "AU_TFN",
        name: "Australian Tax File Number",
        category: "GOV_ID",
        regex: /\b((?:(?:tfn|tax\s+file\s+number)\s*(?:is|\s*[:=\-~])?\s*))(\d{3}\s*\d{3}\s*\d{2,3})\b/gi,
        replacement: "$1[REDACTED_TAX_ID]"
      },
      // 16z-5. Australian Medicare Number (10-11 digits)
      {
        id: "AU_MEDICARE",
        name: "Australian Medicare Number",
        category: "HEALTH",
        regex: /\b((?:(?:medicare(?:\s+number)?)\s*(?:is|\s*[:=\-~])?\s*))([2-6]\d{3}\s*\d{5}\s*\d{1,2})\b/gi,
        replacement: "$1[REDACTED_HEALTH_ID]"
      },
      // 16z-6. Mexican CURP (18 characters)
      {
        id: "MX_CURP",
        name: "Mexican CURP ID",
        category: "GOV_ID",
        regex: /\b((?:(?:curp)\s*[:=\-~]?\s*|(?<=\b)))([A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d)\b/gi,
        replacement: "$1[REDACTED_NATIONAL_ID]"
      },
      // 16z-7. Mexican RFC Tax ID (12-13 characters)
      {
        id: "MX_RFC",
        name: "Mexican RFC Tax ID",
        category: "GOV_ID",
        regex: /\b((?:(?:rfc)\s*[:=\-~]?\s*|(?<=\b)))([A-Z]{3,4}\d{6}[A-Z0-9]{3})\b/gi,
        replacement: "$1[REDACTED_TAX_ID]"
      },
      // 17. Unix / Linux Terminal Shell Prompt (e.g. user@host:~/path$)
      {
        id: "TERMINAL_PROMPT",
        name: "Terminal Shell Prompt",
        category: "SYSTEM",
        regex: /((?:\([a-zA-Z0-9._-]+\)\s*)?)\b([a-zA-Z0-9._-]+)@([a-zA-Z0-9._-]+):([~/\w\s\p{L}.-]+)([\$#])/gu,
        replacement: "$1[user]@[host]:~/[sandbox_path]$5"
      },
      // 13. Kali Linux Modern Shell Prompt (┌──(user㉿host)-[~/path])
      {
        id: "KALI_TERMINAL_PROMPT",
        name: "Kali Linux Shell Prompt",
        category: "SYSTEM",
        regex: /┌──\(([a-zA-Z0-9._-]+)㉿([a-zA-Z0-9._-]+)\)-\[([~/\w\s\p{L}.-]*)\](?:\s*[\r\n]+\s*└─[\$#])?/gu,
        replacement: "┌──([user]㉿[host])-[~/[sandbox_path]]\n└─$"
      },
      // 14. Modern Zsh / Powerline Prompt (e.g. Mon 28 Sep - 18:24  ~  @darflashxd )
      {
        id: "POWERLINE_ZSH_PROMPT",
        name: "Powerline & Modern Zsh Prompt",
        category: "SYSTEM",
        regex: /(?:[A-Za-z]{3}\s+\d{1,2}\s+[A-Za-z]{3}\s+-\s+\d{1,2}:\d{2}\s*[\uE0B0-\uE0B3\s]*)?(?:~[\uE0B0-\uE0B3\s]*)?@([a-zA-Z0-9._-]+)(\s*[\uE0B0-\uE0B3])/gu,
        replacement: "@[user]$2"
      },
      // 15. macOS Default Terminal Prompt (user@host ~ %)
      {
        id: "MACOS_TERMINAL_PROMPT",
        name: "macOS Shell Prompt",
        category: "SYSTEM",
        regex: /\b([a-zA-Z0-9._-]+)@([a-zA-Z0-9._-]+)\s+([~/\w\s\p{L}.-]+)\s*%/gu,
        replacement: "[user]@[host] ~/[sandbox_path] %"
      },
      // 16. Windows PowerShell & CMD Prompt (PS C:\Users\user\path> or C:\Users\user\path>)
      {
        id: "WINDOWS_PROMPT",
        name: "Windows Shell Prompt",
        category: "SYSTEM",
        regex: /\b((?:PS\s+)?[A-Z]:\\Users\\)([a-zA-Z0-9._-]+)(\\[^>\n\r]*)?>/gi,
        replacement: "$1[user]$3>"
      },
      // 17. Git Commit Author Metadata (Author: user <email>)
      {
        id: "GIT_AUTHOR_TRACE",
        name: "Git Author Identity",
        category: "SYSTEM",
        regex: /\b(Author:\s*)([a-zA-Z0-9._\s-]+?)\s*<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,})>/gi,
        replacement: "$1[User_A] <[user@protected.local]>"
      },
      // 18. SSH Public Key Identity Comment (ssh-ed25519 AAA... user@host)
      {
        id: "SSH_KEY_COMMENT",
        name: "SSH Key Identity Comment",
        category: "SYSTEM",
        regex: /\b(ssh-(?:ed25519|rsa|ecdsa|dss)\s+[A-Za-z0-9+/=]{32,}\s+)([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+)\b/g,
        replacement: "$1[user]@[host]"
      },
      // 19. Linux POSIX ID & whoami output (uid=1000(user) gid=1000(group))
      {
        id: "POSIX_ID_OUTPUT",
        name: "POSIX Identity Command Output",
        category: "SYSTEM",
        regex: /\b(uid=\d+\()([a-zA-Z0-9._-]+)(\)\s+gid=\d+\()([a-zA-Z0-9._-]+)(\)(?:\s+groups=[\d(),a-zA-Z0-9._-]+)?)/g,
        replacement: "$1[user]$3[group]) groups=1000([group])"
      },
      // 20. Shell output for whoami and USER environment variable
      {
        id: "WHOAMI_USER_OUTPUT",
        name: "Whoami or USER Command Output",
        category: "SYSTEM",
        regex: /((?:\bwhoami|\$USER)(?:\s*[:=>\->]+\s*|\s+))([a-zA-Z0-9._-]+)\b/gi,
        replacement: "$1[user]"
      },
      // 21. Internal Hostname user@host (Non-TLD, developer handles)
      {
        id: "UNIX_USER_HOST",
        name: "Internal User & Hostname",
        category: "SYSTEM",
        regex: /\b([a-zA-Z0-9._-]+)@([a-zA-Z0-9_-]+)(?!\.[a-zA-Z]{2,})\b/g,
        replacement: "[user]@[host]"
      },
      // 22. User Home Directory Paths (Linux / macOS / Windows)
      {
        id: "USER_HOME_PATH",
        name: "User Home Directory Path",
        category: "SYSTEM",
        regex: /(?:\/home\/|~\/|\/Users\/|[A-Z]:\\Users\\)[a-zA-Z0-9._-]+(?:\/[a-zA-Z0-9_\-.\s\p{L}]+)*/gu,
        replacement: "~/[sandbox_path]"
      }
    ];
  }

  /**
   * Calculates Shannon Entropy of a string to detect high-entropy secrets (passwords, tokens).
   */
  shannonEntropy(str) {
    if (!str || str.length === 0) return 0;
    const freqs = {};
    for (let char of str) {
      freqs[char] = (freqs[char] || 0) + 1;
    }
    let entropy = 0;
    const len = str.length;
    for (let char in freqs) {
      const p = freqs[char] / len;
      entropy -= p * Math.log2(p);
    }
    return entropy;
  }

  validateSSN(val) {
    if (!val) return false;
    const parts = val.split("-");
    if (parts.length !== 3) return false;
    const area = parseInt(parts[0], 10);
    const group = parseInt(parts[1], 10);
    const serial = parseInt(parts[2], 10);
    if (isNaN(area) || isNaN(group) || isNaN(serial)) return false;
    if (area === 0 || area === 666) return false;
    if (group === 0) return false;
    if (serial === 0) return false;
    return true;
  }

  validateRouting(val) {
    if (!val) return false;
    const digits = val.replace(/\D/g, "");
    if (digits.length !== 9) return false;
    const d = digits.split("").map(Number);
    const checksum = (3 * (d[0] + d[3] + d[6]) + 7 * (d[1] + d[4] + d[7]) + 1 * (d[2] + d[5] + d[8])) % 10;
    return checksum === 0;
  }

  validateIBAN(val) {
    if (!val) return false;
    const clean = val.replace(/[\s-]/g, "").toUpperCase();
    if (clean.length < 15 || clean.length > 34) return false;
    const validCountries = new Set([
      "AL", "AD", "AT", "AZ", "BH", "BY", "BE", "BA", "BR", "BG", "CR", "HR", "CY", "CZ", "DK", "DO",
      "EG", "EE", "FO", "FI", "FR", "GE", "DE", "GI", "GR", "GL", "GT", "HU", "IS", "IQ", "IE", "IL",
      "IT", "JO", "KZ", "XK", "KW", "LV", "LB", "LI", "LT", "LU", "MT", "MR", "MU", "MD", "MC", "ME",
      "NL", "MK", "NO", "PK", "PS", "PL", "PT", "QA", "RO", "LC", "SM", "ST", "SA", "RS", "SC", "SK",
      "SI", "ES", "SD", "SE", "CH", "TL", "TN", "TR", "UA", "AE", "GB", "VA", "VG"
    ]);
    const country = clean.substring(0, 2);
    if (!validCountries.has(country)) return false;

    const rearranged = clean.substring(4) + clean.substring(0, 4);
    let numStr = "";
    for (let i = 0; i < rearranged.length; i++) {
      const code = rearranged.charCodeAt(i);
      if (code >= 65 && code <= 90) {
        numStr += (code - 55).toString();
      } else if (code >= 48 && code <= 57) {
        numStr += rearranged[i];
      } else {
        return false;
      }
    }
    let remainder = 0;
    for (let i = 0; i < numStr.length; i += 7) {
      const chunk = remainder.toString() + numStr.substring(i, i + 7);
      remainder = parseInt(chunk, 10) % 97;
    }
    return remainder === 1;
  }

  /**
   * Validates credit card number with Luhn formula.
   */
  luhnCheck(val) {
    const sanitized = val.replace(/\D/g, "");
    if (sanitized.length < 13 || sanitized.length > 19) return false;
    let sum = 0;
    let shouldDouble = false;
    for (let i = sanitized.length - 1; i >= 0; i--) {
      let digit = parseInt(sanitized.charAt(i), 10);
      if (shouldDouble) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      sum += digit;
      shouldDouble = !shouldDouble;
    }
    return sum % 10 === 0;
  }

  hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return hash;
  }

  /**
   * Normalizes Unicode NFKC and maps Cyrillic/Greek lookalikes (homoglyphs) to Latin ASCII.
   * Defeats Unicode homoglyph spoofing and fullwidth/bold evasion attacks.
   */
  normalizeHomoglyphs(text) {
    if (!text || typeof text !== "string") return "";
    // Step 1: Strip zero-width & non-printable evasion markers
    let s = text.replace(/[\u200B-\u200D\uFEFF\u00AD\u2060\u180E]/g, "");
    // Step 2: Unicode NFKC Canonical Decomposition & Compatibility Composition
    s = s.normalize("NFKC");
    // Step 3: Cyrillic / Greek confusable character mapping to Latin ASCII
    const confusableMap = {
      "\u0410": "A", "\u0412": "B", "\u0421": "C", "\u0415": "E", "\u041D": "H",
      "\u0406": "I", "\u0408": "J", "\u041A": "K", "\u041C": "M", "\u041E": "O",
      "\u0420": "P", "\u0405": "S", "\u0422": "T", "\u0425": "X", "\u04AE": "Y",
      "\u0430": "a", "\u0441": "c", "\u0435": "e", "\u0456": "i", "\u0458": "j",
      "\u043A": "k", "\u043E": "o", "\u0440": "p", "\u0455": "s", "\u0445": "x",
      "\u0443": "y", "\u0391": "A", "\u0392": "B", "\u0395": "E", "\u0397": "H",
      "\u0399": "I", "\u039A": "K", "\u039C": "M", "\u039D": "N", "\u039F": "O",
      "\u03A1": "P", "\u03A4": "T", "\u03A7": "X", "\u03BF": "o"
    };
    return s.replace(/[\u0410-\u0458\u0391-\u03BF]/g, (ch) => confusableMap[ch] || ch);
  }

  /**
   * Scans and redacts deterministic secrets and PII from input text.
   * Returns: { sanitizedText, detections: [{ type, matched, offset, length }] }
   */
  scan(text) {
    if (!text) return { sanitizedText: "", detections: [] };
    // Pre-processing: Apply Homoglyph normalization & strip zero-width characters
    text = this.normalizeHomoglyphs(text);
    let sanitizedText = text;
    const detections = [];

    for (const pattern of this.patterns) {
      let match;
      const regex = new RegExp(pattern.regex.source, pattern.regex.flags);
      
      while ((match = regex.exec(text)) !== null) {
        const raw = match[0];
        if (pattern.validator && !pattern.validator(raw, match.index, text)) {
          continue;
        }

        let repl;
        if (typeof pattern.replacement === "function") {
          repl = pattern.replacement(raw, match.index, text);
        } else if (typeof pattern.replacement === "string" && pattern.replacement.includes("$")) {
          repl = raw.replace(new RegExp(pattern.regex.source, pattern.regex.flags), pattern.replacement);
        } else {
          repl = pattern.replacement;
        }

        let secretToken = (match.length > 2 && match[2]) ? match[2] : raw;
        if (pattern.id === "CARD_SECURITY_CODE" && typeof secretToken === "string") {
          secretToken = secretToken.replace(/\D/g, "");
        }

        detections.push({
          type: pattern.id,
          name: pattern.name,
          category: pattern.category || "GENERAL",
          raw: raw,
          secretToken: secretToken,
          replacement: repl,
          index: match.index,
          length: raw.length
        });
      }
    }

    // Resolve overlapping detections: prefer larger spans (e.g. TERMINAL_PROMPT over inner user@host)
    const sortedByLength = [...detections].sort((a, b) => b.length - a.length);
    const nonOverlapping = [];

    for (const det of sortedByLength) {
      const detStart = det.index;
      const detEnd = det.index + det.length;
      let overlaps = false;
      for (const acc of nonOverlapping) {
        const accStart = acc.index;
        const accEnd = acc.index + acc.length;
        if (detStart < accEnd && detEnd > accStart) {
          overlaps = true;
          break;
        }
      }
      if (!overlaps) {
        nonOverlapping.push(det);
      }
    }

    // Apply replacements from back to front to preserve offsets
    nonOverlapping.sort((a, b) => b.index - a.index);
    for (const det of nonOverlapping) {
      sanitizedText = 
        sanitizedText.substring(0, det.index) + 
        det.replacement + 
        sanitizedText.substring(det.index + det.length);
    }

    return {
      sanitizedText,
      detections: nonOverlapping
    };
  }
}

// Export for ES module or extension content script
if (typeof module !== "undefined" && module.exports) {
  module.exports = HeuristicsRedactor;
}
