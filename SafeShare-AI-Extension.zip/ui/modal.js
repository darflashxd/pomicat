/**
 * SafeShare-AI — Modal Controller
 * Coordinates the 3-Tier Redaction Pipeline and Zero-Knowledge Encryption Flow.
 */

class SafeShareModal {
  constructor() {
    this.heuristics = new HeuristicsRedactor();
    this.contextual = new ContextualClassifier();
    this.pseudonymizer = new ConsistentPseudonymizer();
    this.crypto = new SafeShareCrypto();
    this.currentTurns = [];
    this.sanitizedTurns = [];
  }

  /**
   * Initializes and opens the SafeShare modal with extracted conversation turns.
   */
  open(turns) {
    this.currentTurns = turns;
    this.removeExisting();

    const backdrop = document.createElement("div");
    backdrop.id = "safeshare-modal-backdrop";
    backdrop.innerHTML = `
      <div id="safeshare-modal-card">
        <div class="safeshare-header">
          <div class="safeshare-brand">
            <div class="safeshare-logo">🛡️</div>
            <div class="safeshare-title">SafeShare-AI Guard</div>
            <span class="safeshare-badge">ZERO-KNOWLEDGE #FRAGMENT</span>
          </div>
          <button class="safeshare-close-btn" id="safeshare-close-btn">&times;</button>
        </div>

        <div class="safeshare-stats-bar">
          <div class="stat-item">
            <div class="stat-label">Chat Turns</div>
            <div class="stat-val" id="stat-turns">${turns.length}</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Hard Secrets Redacted</div>
            <div class="stat-val" id="stat-hard-secrets" style="color: #ef4444;">0</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Contextual Entities Masked</div>
            <div class="stat-val" id="stat-contextual" style="color: #f59e0b;">0</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Crawler Immunity</div>
            <div class="stat-val" style="color: #10b981;">100% SECURE</div>
          </div>
        </div>

        <div class="safeshare-body" id="safeshare-review-view">
          <div class="diff-section-title">
            <span>PRE-FLIGHT REDACTION DIFF (SIDE-BY-SIDE AUDIT)</span>
            <span style="font-size: 11px; color: #38bdf8;">✓ RFC 3986 Encrypted Fragment</span>
          </div>
          <div class="diff-container">
            <div>
              <div style="font-size: 11px; color: #94a3b8; margin-bottom: 6px;">ORIGINAL (CONTAINS PII/SECRETS)</div>
              <div class="diff-box" id="diff-box-orig"></div>
            </div>
            <div>
              <div style="font-size: 11px; color: #94a3b8; margin-bottom: 6px;">SANITIZED OUTPUT (SAFE FOR SHARE)</div>
              <div class="diff-box" id="diff-box-sanitized"></div>
            </div>
          </div>

          <div class="safeshare-options">
            <div class="option-group">
              <span>⏱️ Ephemeral Link Expiration:</span>
              <select class="select-dropdown" id="safeshare-ttl">
                <option value="86400">24 Hours (Recommended)</option>
                <option value="259200">3 Days</option>
                <option value="604800">7 Days</option>
                <option value="burn">Burn-After-Reading (1 View)</option>
              </select>
            </div>
            <div class="option-group">
              <span>🔒 Zero-Knowledge Proof:</span>
              <span style="font-size: 12px; color: #10b981; font-weight: 600;">Client-Side AES-GCM-256</span>
            </div>
          </div>
        </div>

        <!-- Success Result View -->
        <div class="safeshare-body result-view" id="safeshare-result-view">
          <div style="font-size: 40px; margin-bottom: 10px;">🔐</div>
          <h3 style="color: #fff; margin: 0 0 8px 0; font-size: 20px;">Zero-Knowledge Share Link Ready!</h3>
          <p style="color: #94a3b8; font-size: 13.5px; max-width: 500px; margin: 0 auto;">
            The secret key is embedded inside the URL hash fragment (#). Search engines and web crawlers 
            cannot read this data.
          </p>

          <div class="result-url-box">
            <div class="result-url-text" id="result-url-display">https://safeshare.app/v/...</div>
            <button class="btn-primary" id="btn-copy-url" style="padding: 6px 14px; font-size: 12.5px;">Copy Link</button>
          </div>

          <div style="display: inline-block; padding: 6px 14px; border-radius: 20px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #10b981; font-size: 12.5px; font-weight: 600;">
            ✓ 0% Ketergantungan Laptop • Bebas Dimatikan • Berlaku 24 Jam • Universal Continue
          </div>
        </div>

        <div class="safeshare-footer" id="safeshare-modal-footer">
          <button class="btn-secondary" id="btn-cancel">Cancel</button>
          <button class="btn-primary" id="btn-encrypt-publish">Generate ZK Share Link 🚀</button>
        </div>
      </div>
    `;

    document.body.appendChild(backdrop);
    this.bindEvents(backdrop);
    this.runPipeline();
  }

  removeExisting() {
    const existing = document.getElementById("safeshare-modal-backdrop");
    if (existing) existing.remove();
  }

  /**
   * Executes the 3-Tier Redaction Pipeline on captured turns.
   */
  runPipeline() {
    this.pseudonymizer.reset();
    let totalHardSecrets = 0;
    let totalContextual = 0;

    let origTextDisplay = "";
    let sanitizedTextDisplay = "";

    const detectedContextualEntities = [];
    const intermediateTurns = [];

    // Step 1: Run Tier 1 (Heuristics) & Tier 2 (Contextual) per turn
    for (let i = 0; i < this.currentTurns.length; i++) {
      const turn = this.currentTurns[i];
      origTextDisplay += `[${turn.role.toUpperCase()}]: ${turn.content}\n\n`;

      // Tier 1: Heuristic hard secrets
      const hResult = this.heuristics.scan(turn.content);
      totalHardSecrets += hResult.detections.length;

      // Tier 2: Contextual entities
      const cDetections = this.contextual.classifyTurn(hResult.sanitizedText, i);
      totalContextual += cDetections.length;
      detectedContextualEntities.push(...cDetections);

      intermediateTurns.push({
        role: turn.role,
        content: hResult.sanitizedText
      });
    }

    // Step 2: Run Tier 3 Consistent Pseudonymization
    const { anonymizedTurns } = this.pseudonymizer.anonymizeConversation(
      intermediateTurns,
      detectedContextualEntities
    );
    this.sanitizedTurns = anonymizedTurns;

    for (const turn of this.sanitizedTurns) {
      sanitizedTextDisplay += `[${turn.role.toUpperCase()}]: ${turn.content}\n\n`;
    }

    // Update Stats & Diff Boxes
    document.getElementById("stat-hard-secrets").innerText = totalHardSecrets;
    document.getElementById("stat-contextual").innerText = totalContextual;
    document.getElementById("diff-box-orig").innerText = origTextDisplay;
    document.getElementById("diff-box-sanitized").innerText = sanitizedTextDisplay;
  }

  bindEvents(backdrop) {
    backdrop.querySelector("#safeshare-close-btn").addEventListener("click", () => this.removeExisting());
    backdrop.querySelector("#btn-cancel").addEventListener("click", () => this.removeExisting());

    // Publish & Encrypt Event
    backdrop.querySelector("#btn-encrypt-publish").addEventListener("click", async () => {
      const btn = backdrop.querySelector("#btn-encrypt-publish");
      btn.innerText = "Encrypting (AES-GCM)...";
      btn.disabled = true;

      try {
        const ttl = document.getElementById("safeshare-ttl").value;
        const payload = {
          turns: this.sanitizedTurns,
          timestamp: new Date().toISOString(),
          ttl: ttl
        };

        const encResult = await this.crypto.encrypt(payload);

        let finalShareUrl = encResult.fullShareUrl;

        // Upload ciphertext to relay server via background script (bypasses webpage CSP)
        const relayUrl = this.crypto.relayBaseUrl || "http://localhost:8787";
        const uploadPayload = {
          id: encResult.shareId,
          ciphertext: encResult.ciphertext,
          ttl: ttl
        };

        try {
          if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            await new Promise((resolve, reject) => {
              chrome.runtime.sendMessage(
                {
                  action: "UPLOAD_TO_RELAY",
                  relayUrl: relayUrl,
                  payload: uploadPayload
                },
                (res) => {
                  if (chrome.runtime.lastError) {
                    return reject(new Error(chrome.runtime.lastError.message));
                  }
                  if (!res || !res.success) {
                    return reject(new Error(res ? res.error : "Background upload failed"));
                  }
                  resolve(res.data);
                }
              );
            });
          } else {
            // Fallback for standalone local script testing
            const uploadRes = await fetch(`${relayUrl}/api/share`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(uploadPayload)
            });
            if (!uploadRes.ok) {
              throw new Error(`Relay upload failed with status ${uploadRes.status}`);
            }
          }
        } catch (relayErr) {
          console.warn("[SafeShare] Relay unavailable, seamlessly switching to Zero-Server Standalone link:", relayErr);
          finalShareUrl = encResult.standaloneShareUrl;
        }

        // Switch to Result View
        document.getElementById("safeshare-review-view").style.display = "none";
        document.getElementById("safeshare-modal-footer").style.display = "none";
        document.getElementById("safeshare-result-view").style.display = "block";

        const urlDisplay = document.getElementById("result-url-display");
        urlDisplay.innerText = finalShareUrl;

        // Copy button
        const copyBtn = document.getElementById("btn-copy-url");
        copyBtn.onclick = async () => {
          await navigator.clipboard.writeText(finalShareUrl);
          copyBtn.innerText = "Copied! ✓";
          setTimeout(() => (copyBtn.innerText = "Copy Link"), 2500);
        };
      } catch (err) {
        console.error("[SafeShare] Encryption error:", err);
        btn.innerText = "Error Encrypting";
        btn.disabled = false;
      }
    });
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = SafeShareModal;
}
