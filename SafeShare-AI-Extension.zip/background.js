/**
 * SafeShare-AI — Background Service Worker
 * Handles network relay uploads securely from an isolated privileged context,
 * completely bypassing webpage CSP (Content Security Policy) and Mixed Content blocks.
 */

console.log("[SafeShare-AI] Background script initialized.");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "UPLOAD_TO_RELAY") {
    const { relayUrl, payload } = request;
    console.log("[SafeShare-AI Background] Relaying upload to:", `${relayUrl}/api/share`);

    fetch(`${relayUrl}/api/share`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    })
      .then(async (response) => {
        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`Relay returned status ${response.status}: ${errText}`);
        }
        return response.json();
      })
      .then((data) => {
        console.log("[SafeShare-AI Background] Upload success:", data);
        sendResponse({ success: true, data });
      })
      .catch((err) => {
        console.error("[SafeShare-AI Background] Upload failed:", err);
        sendResponse({ success: false, error: err.message });
      });

    return true; // Keep message channel open for async response
  }
});
