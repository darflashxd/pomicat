/**
 * SafeShare-AI — Content Script
 * Injects SafeShare action button into ChatGPT, Claude, and DeepSeek interfaces
 * and extracts conversation context.
 */

(function () {
  console.log("[SafeShare-AI] Extension content script active.");

  function initSafeShareButton() {
    if (document.getElementById("safeshare-action-pill")) return;

    const pill = document.createElement("button");
    pill.id = "safeshare-action-pill";
    pill.innerHTML = `<span>🛡️</span> <b>SafeShare (ZK)</b>`;
    pill.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 28px;
      z-index: 99999;
      background: linear-gradient(135deg, #06b6d4, #2563eb);
      color: #fff;
      border: 1px solid rgba(255,255,255,0.25);
      border-radius: 30px;
      padding: 10px 18px;
      font-size: 13.5px;
      font-weight: 700;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-shadow: 0 8px 24px rgba(6, 182, 212, 0.45);
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease-in-out;
    `;

    pill.addEventListener("mouseenter", () => {
      pill.style.transform = "scale(1.05)";
    });
    pill.addEventListener("mouseleave", () => {
      pill.style.transform = "scale(1.0)";
    });

    pill.addEventListener("click", () => {
      const turns = extractConversationTurns();
      if (turns.length === 0) {
        alert("SafeShare: Belum ada percakapan aktif di jendela chat.");
        return;
      }
      const modal = new SafeShareModal();
      modal.open(turns);
    });

    document.body.appendChild(pill);
  }

  /**
   * Universal extractor for ChatGPT, Claude, and DeepSeek conversation nodes.
   */
  function extractConversationTurns() {
    const turns = [];

    // 0. High-accuracy ChatGPT data-message-author-role pattern
    const roleDivs = document.querySelectorAll("[data-message-author-role]");
    if (roleDivs.length > 0) {
      roleDivs.forEach((el) => {
        const role = el.getAttribute("data-message-author-role");
        const content = el.innerText.trim();
        if (content) {
          turns.push({ role, content });
        }
      });
      return turns;
    }

    // 1. ChatGPT article turn pattern
    const chatGptArticles = document.querySelectorAll("article[data-testid^='conversation-turn']");
    if (chatGptArticles.length > 0) {
      chatGptArticles.forEach((art, idx) => {
        const isAssistant = art.querySelector("[data-message-author-role='assistant']") !== null;
        const textContent = art.innerText || "";
        turns.push({
          role: isAssistant ? "assistant" : "user",
          content: textContent.trim()
        });
      });
      return turns;
    }

    // 2. Claude DOM Pattern
    const claudeMessages = document.querySelectorAll("[data-testid='user-message'], .font-claude-message");
    if (claudeMessages.length > 0) {
      claudeMessages.forEach((el) => {
        const isUser = el.getAttribute("data-testid") === "user-message";
        turns.push({
          role: isUser ? "user" : "assistant",
          content: el.innerText.trim()
        });
      });
      return turns;
    }

    // 3. Fallback: Generic turn extraction
    const allParas = document.querySelectorAll("main p, .chat-message, [role='presentation'] p");
    let buffer = [];
    allParas.forEach((p, idx) => {
      if (p.innerText.trim()) {
        turns.push({
          role: idx % 2 === 0 ? "user" : "assistant",
          content: p.innerText.trim()
        });
      }
    });

    return turns;
  }

  // Periodic check to inject button once UI is loaded
  setInterval(initSafeShareButton, 1500);
})();
