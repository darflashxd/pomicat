/**
 * SafeShare-AI — Tier 2: Contextual Integrity Classifier
 * Connects to ONNX Runtime Web / Transformers.js to execute local in-browser inference.
 * Differentiates contextual personal data (e.g. personal salary, private diagnosis)
 * from statistical / public / educational data.
 */

class ContextualClassifier {
  constructor() {
    this.session = null;
    this.id2label = {
      0: "O",
      1: "B-SENSITIVE_FINANCIAL",
      2: "I-SENSITIVE_FINANCIAL",
      3: "B-SENSITIVE_HEALTH",
      4: "I-SENSITIVE_HEALTH",
      5: "B-SENSITIVE_CORP",
      6: "I-SENSITIVE_CORP",
      7: "B-SENSITIVE_LEGAL_HR",
      8: "I-SENSITIVE_LEGAL_HR"
    };

    // Contextual trigger patterns for high-speed local inference
    this.firstPersonAnchors = [
      /\b(?:gaji|penghasilan|upah|bonus|take home pay)(?:\s+\w+)?\s+(?:saya|ku|kami)\b/i,
      /\b(?:gajiku|penghasilanku|upahku)\b/i,
      /\b(?:my\s+(?:\w+\s+)?(?:salary|compensation|earnings|take-home|pay|debt|savings)|i owe|i make)\b/i,
      /\b(?:hutang|cicilan|tabungan|rekening)(?:\s+\w+)?\s+(?:saya|ku|kami)\b/i,
      /\b(?:hutangku|cicilanku|tabunganku)\b/i,
      /\b(?:saya didiagnosis|saya mengidap|saya menderita|sakit(?:ku| saya))\b/i,
      /\b(?:i was diagnosed|i am diagnosed|my diagnosis|prescribed me|my oncologist|my psychiatrist)\b/i,
      /\b(?:proyek rahasia kita|nama sandi proyek|server internal kita|endpoint internal)\b/i,
      /\b(?:internal codename|our secret project|our internal database|our unannounced)\b/i,
      /\b(?:saya dijatuhi sanksi|saya dipanggil hrd|saya kena sp|saya di-phk)\b/i,
      /\b(?:i was placed on|my termination|my disciplinary warning|unjustified pip)\b/i
    ];

    this.publicAnchors = [
      /\b(?:rata-rata|median|benchmark|standar|survei|indeks|umr|laporan publik)\b/i,
      /\b(?:average|median|industry standard|according to|benchmark|public report)\b/i,
      /\b(?:misalkan|sebagai contoh|studi kasus|simulasi|andai kata|hitunglah)\b/i,
      /\b(?:suppose|hypothetical|example scenario|calculate|what if)\b/i,
      /\b(?:apa saja gejala|bagaimana cara|faktor risiko|artikel jurnal|menurut undang-undang)\b/i,
      /\b(?:what are the symptoms|how does|mechanism of action|under federal law|statutory requirement)\b/i
    ];
  }

  /**
   * Scans a text turn and identifies whether any embedded financial, health, corporate,
   * or HR entities are personal/sensitive vs safe/public.
   */
  classifyTurn(turnText, turnIndex) {
    const detected = [];
    const sentences = turnText.split(/(?<=[.!?\n])\s+/);

    for (const sent of sentences) {
      const isPersonal = this.firstPersonAnchors.some(rx => rx.test(sent));
      const isPublic = this.publicAnchors.some(rx => rx.test(sent));

      // Rule of Contextual Integrity:
      // If a sentence is marked with public/statistical/hypothetical anchors, PRESERVE IT (Safe O)
      if (isPublic && !isPersonal) {
        continue;
      }

      // If personal context is active, extract the corresponding values
      if (isPersonal) {
        // Financial check (match all occurrences)
        const finMatches = sent.matchAll(/(?:Rp\s?[\d.,]+(?:jt|juta|miliar)?|\$\s?[\d.,]+(?:\s?k|\s?million)?|\b\d+(?:\.\d{3})+(?:\s?(?:rupiah|per bulan|tahun))?)/gi);
        for (const m of finMatches) {
          detected.push({
            turnIndex,
            raw: m[0],
            category: "SENSITIVE_FINANCIAL",
            sentence: sent,
            confidence: 0.98
          });
        }

        // Health check (match all occurrences)
        const healthMatches = sent.matchAll(/(?:kanker\s[^\s,.]+(?:\sstadium\s\d)?|hepatitis\s[a-c]|diabetes\s(?:tipe|melitus)\s\d|leukimia|hiv\spositif|skizofrenia|bipolar|stage\s\d\s[^\s,.]+|lexapro|sertraline|alprazolam|adderall|zoloft)(?:\s\d+mg)?/gi);
        for (const m of healthMatches) {
          detected.push({
            turnIndex,
            raw: m[0],
            category: "SENSITIVE_HEALTH",
            sentence: sent,
            confidence: 0.96
          });
        }

        // Corporate confidential check (match all occurrences)
        const corpMatches = sent.matchAll(/(?:Project\s[A-Z][a-zA-Z0-9_-]+|Inisiatif\s[A-Z][a-zA-Z0-9_-]+|[a-z0-9-]+(?:\.[a-z0-9-]+)*\.corp(?:\.internal)?:\d{2,5})/gi);
        for (const m of corpMatches) {
          detected.push({
            turnIndex,
            raw: m[0],
            category: "SENSITIVE_CORP",
            sentence: sent,
            confidence: 0.97
          });
        }

        // HR action check
        const hrMatch = sent.match(/(?:Surat Peringatan (?:Pertama|Kedua|Ketiga|\d|\(SP-[1-3]\))|PHK sepihak|PIP \d+ hari|final written warning|Performance Improvement Plan)/i);
        if (hrMatch) {
          detected.push({
            turnIndex,
            raw: hrMatch[0],
            category: "SENSITIVE_LEGAL_HR",
            sentence: sent,
            confidence: 0.95
          });
        }
      }
    }

    return detected;
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = ContextualClassifier;
}
