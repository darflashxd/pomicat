/**
 * SafeShare-AI — Tier 3: Canonical Equivalence Class & Global Cross-Turn Sweeper
 * 
 * Neutralizes "Echo & Derivation Leakage":
 * When an AI assistant echoes user data, formats it with abbreviations (e.g. "Rp28,5 jt"),
 * calculates annualized earnings ("Rp342 juta/tahun"), computes remainders ("Rp14,3 juta"),
 * or ratios ("49,8%"), this engine builds canonical equivalence clusters and scrubs
 * the entire conversation history (User and Assistant turns) using consistent pseudonyms.
 */

class ConsistentPseudonymizer {
  constructor() {
    this.entityMap = new Map();
    this.counters = {
      USER: 1,
      CORP: 1,
      FINANCIAL: 1,
      HEALTH: 1,
      HR: 1,
      PROJECT: 1
    };
  }

  reset() {
    this.entityMap.clear();
    for (let k in this.counters) {
      this.counters[k] = 1;
    }
  }

  /**
   * Generates or retrieves an existing consistent pseudonym for an entity.
   */
  getPseudonym(rawEntity, category) {
    const key = `${category}::${rawEntity.trim().toLowerCase()}`;
    if (this.entityMap.has(key)) {
      return this.entityMap.get(key);
    }

    let pseudonym;
    switch (category) {
      case "SENSITIVE_FINANCIAL":
        pseudonym = `[REDACTED_FINANCIAL_${this.counters.FINANCIAL++}]`;
        break;
      case "SENSITIVE_HEALTH":
        pseudonym = `[CONFIDENTIAL_HEALTH_RECORD_${this.counters.HEALTH++}]`;
        break;
      case "SENSITIVE_CORP":
        pseudonym = `[INTERNAL_CORP_ASSET_${this.counters.CORP++}]`;
        break;
      case "SENSITIVE_LEGAL_HR":
        pseudonym = `[HR_DISCIPLINARY_RECORD_${this.counters.HR++}]`;
        break;
      case "USER":
        pseudonym = `[User_${String.fromCharCode(64 + this.counters.USER++)}]`;
        break;
      default:
        pseudonym = `[ANONYMIZED_ENTITY_${this.counters.PROJECT++}]`;
    }

    this.entityMap.set(key, pseudonym);
    return pseudonym;
  }

  /**
   * Builds an Equivalence Class of regex patterns for an entity, capturing all
   * abbreviations, reformattings, and arithmetic derivations made by LLMs.
   */
  buildEquivalenceVariants(raw, category, allEntities = []) {
    const variants = [];
    const escapedRaw = raw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    variants.push(escapedRaw);

    if (category === "SENSITIVE_FINANCIAL") {
      const digits = raw.replace(/\D/g, "");
      const num = parseInt(digits, 10);
      if (num && !isNaN(num) && num > 1000) {
        const idFormatted = num.toLocaleString("id-ID").replace(/\./g, "\\.");
        const enFormatted = num.toLocaleString("en-US").replace(/,/g, ",");

        // 1. Currency prefix + formatted number or plain number
        variants.push(`(?:Rp\\s*|IDR\\s*|\\$\\s*)?${idFormatted}\\b`);
        variants.push(`(?:Rp\\s*|IDR\\s*|\\$\\s*)?${enFormatted}\\b`);
        variants.push(`\\b${num}\\b`);

        // 2. Millions abbreviations (e.g. 28,5 juta, 28.5 jt, 28,5 jt)
        if (num >= 1e5) {
          const millions = num / 1e6;
          const milDot = millions.toString().replace(".", "\\.");
          const milComma = millions.toString().replace(".", ",");
          variants.push(`(?:Rp\\s*|IDR\\s*|\\$\\s*)?(?:${milDot}|${milComma})\\s*(?:juta|jt|million|m)\\b`);
          
          if (millions === Math.floor(millions)) {
            variants.push(`(?:Rp\\s*|IDR\\s*|\\$\\s*)?${Math.floor(millions)}\\s*(?:juta|jt|million|m)\\b`);
          }

          // 3. Annualized derivations (LLM multiplying monthly salary by 12)
          const annual = num * 12;
          const annualM = annual / 1e6;
          const annDot = annualM.toString().replace(".", "\\.");
          const annComma = annualM.toString().replace(".", ",");
          variants.push(`(?:Rp\\s*|IDR\\s*|\\$\\s*)?(?:${annDot}|${annComma})\\s*(?:juta|jt|million|m)(?:\\s*\\/\\s*tahun|\\s*per\\s*tahun)?\\b`);
          variants.push(`(?:Rp\\s*|IDR\\s*|\\$\\s*)?${annual.toLocaleString("id-ID").replace(/\./g, "\\.")}\\b`);
        }
      }
    } else if (category === "SENSITIVE_HEALTH") {
      const drugEquivalents = {
        "lexapro": ["escitalopram", "cipralex"],
        "escitalopram": ["lexapro", "cipralex"],
        "cipralex": ["escitalopram", "lexapro"],
        "zoloft": ["sertraline"],
        "sertraline": ["zoloft"],
        "prozac": ["fluoxetine"],
        "fluoxetine": ["prozac"],
        "xanax": ["alprazolam"],
        "alprazolam": ["xanax"],
        "valium": ["diazepam"],
        "diazepam": ["valium"],
        "adderall": ["amphetamine", "dextroamphetamine"],
        "ritalin": ["methylphenidate", "concerta"],
        "concerta": ["methylphenidate", "ritalin"],
        "methylphenidate": ["ritalin", "concerta"],
        "cymbalta": ["duloxetine"],
        "duloxetine": ["cymbalta"],
        "glucophage": ["metformin"],
        "metformin": ["glucophage"],
        "lipitor": ["atorvastatin"],
        "atorvastatin": ["lipitor"]
      };

      const words = raw.toLowerCase().split(/\s+/);
      const synonyms = new Set();
      for (let w of words) {
        if (drugEquivalents[w]) {
          drugEquivalents[w].forEach(syn => synonyms.add(syn));
        }
      }

      // Add base drug brand/name variants
      const parts = raw.split(/\s+/);
      if (parts.length > 1) {
        const brandName = parts[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        variants.push(`\\b(?:obat\\s+)?${brandName}(?:\\s+\\d+\\s*mg)?\\b`);
      }

      // Add all recognized generic/brand synonyms
      for (let syn of synonyms) {
        const escapedSyn = syn.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        variants.push(`\\b(?:obat\\s+)?${escapedSyn}(?:\\s+\\d+\\s*mg)?\\b`);
      }
    } else if (category === "SENSITIVE_CORP") {
      // e.g. "Project Valkyrie Core" -> also match "Project Valkyrie", "Valkyrie Core"
      const match = raw.match(/Project\s+([A-Z][a-z0-9]+)/i);
      if (match) {
        variants.push(`\\bProject\\s+${match[1]}(?:\\s+[A-Z][a-z0-9]+)?\\b`);
      }
    } else if (category === "USER") {
      // Build full name, sub-sequences, and individual name words
      const words = raw.trim().split(/\s+/);
      // 1. Full name
      variants.push(`\\b${words.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('\\s+')}\\b`);
      
      // 2. Multi-word sub-combinations (e.g. "Budianto Kusuma", "Kusuma Alama")
      for (let i = 0; i < words.length; i++) {
        for (let j = i + 2; j <= words.length; j++) {
          if (j - i < words.length) {
            variants.push(`\\b${words.slice(i, j).map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('\\s+')}\\b`);
          }
        }
      }

      // 3. Individual name tokens (>= 3 chars to prevent false matches with prepositions)
      for (let w of words) {
        if (w.length >= 3) {
          variants.push(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`);
        }
      }
    }

    return variants;
  }

  /**
   * Sweeps and neutralizes entities and their equivalence classes across ALL turns (User & Assistant).
   * @param {Array<{role: string, content: string}>} turns
   * @param {Array<{turnIndex: number, raw: string, category: string}>} detectedEntities
   */
  anonymizeConversation(turns, detectedEntities) {
    const updatedTurns = JSON.parse(JSON.stringify(turns));

    // Extract user name if introduced in user prompt, respecting stop-words and clause boundaries
    const userIntroMatches = [];
    const nameStopWords = new Set([
      "alamat", "tinggal", "umur", "usia", "nomor", "no", "telfon", "telepon", "hp", "wa",
      "email", "bekerja", "dan", "dari", "lahir", "nik", "kpr", "gaji", "di", "jalan", "jl",
      "address", "phone", "living", "working", "born", "age", "years", "my", "saya"
    ]);

    turns.forEach((turn, idx) => {
      if (turn.role === "user") {
        const nameRx = /(?:\b(?:nama saya|namaku|my name is|i am|call me)\s+)([^,.\n!?]+)/gi;
        let nm;
        while ((nm = nameRx.exec(turn.content)) !== null) {
          const rawPhrase = nm[1].trim();
          const words = rawPhrase.split(/\s+/);
          const nameTokens = [];
          for (const w of words) {
            const clean = w.toLowerCase().replace(/[^a-z]/g, "");
            if (nameStopWords.has(clean)) break;
            nameTokens.push(w);
            if (nameTokens.length >= 4) break; // Max 4 words for a realistic name
          }
          if (nameTokens.length > 0) {
            userIntroMatches.push({
              turnIndex: idx,
              raw: nameTokens.join(" "),
              category: "USER"
            });
          }
        }
      }
    });

    const allTargets = [...detectedEntities, ...userIntroMatches];

    // Compute arithmetic derivations between financial pairs (e.g. Remainder and Ratios)
    const financialNums = allTargets
      .filter(e => e.category === "SENSITIVE_FINANCIAL")
      .map(e => ({ raw: e.raw, val: parseInt(e.raw.replace(/\D/g, ""), 10) }))
      .filter(e => !isNaN(e.val) && e.val > 0);

    const derivedPatterns = [];
    if (financialNums.length >= 2) {
      const sorted = [...financialNums].sort((a, b) => b.val - a.val);
      const valA = sorted[0].val; // e.g. 28.5M
      const valB = sorted[1].val; // e.g. 14.2M
      const diff = valA - valB;   // e.g. 14.3M

      if (diff > 0) {
        const diffM = diff / 1e6;
        const diffDot = diffM.toFixed(1).replace(".", "\\.");
        const diffComma = diffM.toFixed(1).replace(".", ",");
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?(?:${diffDot}|${diffComma})\\s*(?:juta|jt|million|m)\\b`,
          replacement: "[REDACTED_REMAINDER_CASHFLOW]"
        });
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?${diff.toLocaleString("id-ID").replace(/\./g, "\\.")}\\b`,
          replacement: "[REDACTED_REMAINDER_CASHFLOW]"
        });
      }

      // Debt ratio e.g. 14.2 / 28.5 = 49.8%
      const ratio = ((valB / valA) * 100).toFixed(1);
      const ratioDot = ratio.replace(".", "\\.");
      const ratioComma = ratio.replace(".", ",");
      derivedPatterns.push({
        pattern: `\\b(?:${ratioDot}|${ratioComma})\\s*%\\b`,
        replacement: "[REDACTED_DEBT_RATIO]"
      });
    }

    // Neutralize Percentage Projection Clusters & Compound Residuals
    const percentages = [5, 10, 12, 15, 20, 25, 30, 35, 40, 50];
    for (const item of financialNums) {
      const val = item.val;
      for (const p of percentages) {
        const total = Math.round(val * (1 + p / 100));
        const delta = Math.round(val * (p / 100));

        // 1. Full formatted total (highest specificity)
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?${total.toLocaleString("id-ID").replace(/\./g, "\\.")}\\b`,
          replacement: "[REDACTED_PROJECTED_SALARY]"
        });
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?${total.toLocaleString("en-US").replace(/,/g, ",")}\\b`,
          replacement: "[REDACTED_PROJECTED_SALARY]"
        });

        // 2. Abbreviated millions total (MUST require juta/jt explicitly so .000 never dangles)
        const totalM = total / 1e6;
        const totDot = totalM.toString().replace(".", "\\.");
        const totComma = totalM.toString().replace(".", ",");
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?(?:${totDot}|${totComma})\\s*(?:juta|jt|million|m)\\b`,
          replacement: "[REDACTED_PROJECTED_SALARY]"
        });

        // 3. Full formatted delta increment
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?${delta.toLocaleString("id-ID").replace(/\./g, "\\.")}\\b`,
          replacement: "[REDACTED_SALARY_INCREMENT]"
        });
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?${delta.toLocaleString("en-US").replace(/,/g, ",")}\\b`,
          replacement: "[REDACTED_SALARY_INCREMENT]"
        });

        // 4. Abbreviated millions delta
        const deltaM = delta / 1e6;
        const delDot = deltaM.toString().replace(".", "\\.");
        const delComma = deltaM.toString().replace(".", ",");
        derivedPatterns.push({
          pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?(?:${delDot}|${delComma})\\s*(?:juta|jt|million|m)(?:\\s*(?:per bulan|\\/bulan))?\\b`,
          replacement: "[REDACTED_SALARY_INCREMENT]"
        });

        // 5. Compound Residual Formula: (Gaji * (1 + p)) - Hutang
        if (financialNums.length >= 2) {
          const debtVal = financialNums.find(f => f.val < val)?.val;
          if (debtVal) {
            const remainder = total - debtVal;
            if (remainder > 0) {
              const remM = remainder / 1e6;
              const remDot = remM.toString().replace(".", "\\.");
              const remComma = remM.toString().replace(".", ",");
              derivedPatterns.push({
                pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?${remainder.toLocaleString("id-ID").replace(/\./g, "\\.")}\\b`,
                replacement: "[REDACTED_PROJECTED_CASHFLOW]"
              });
              derivedPatterns.push({
                pattern: `(?:Rp\\s*|IDR\\s*|\\$\\s*)?(?:${remDot}|${remComma})\\s*(?:juta|jt|million|m)\\b`,
                replacement: "[REDACTED_PROJECTED_CASHFLOW]"
              });
            }
          }
        }
      }
    }

    // Build replacement clusters for all target entities
    const replacementRules = [];

    for (const ent of allTargets) {
      const pseudo = this.getPseudonym(ent.raw, ent.category);
      const variants = this.buildEquivalenceVariants(ent.raw, ent.category, allTargets);

      for (const v of variants) {
        replacementRules.push({
          regexStr: v,
          replacement: pseudo,
          length: v.length
        });
      }
    }

    // Add derived arithmetic patterns
    for (const dp of derivedPatterns) {
      replacementRules.push({
        regexStr: dp.pattern,
        replacement: dp.replacement,
        length: dp.pattern.length
      });
    }

    // Sort replacement rules by pattern specificity (longest pattern first)
    replacementRules.sort((a, b) => b.length - a.length);

    // Global sweep across EVERY turn in the conversation
    for (const rule of replacementRules) {
      const reg = new RegExp(rule.regexStr, "gi");
      for (let turn of updatedTurns) {
        if (turn.content) {
          turn.content = turn.content.replace(reg, rule.replacement);
        }
      }
    }

    // Syntactic Arrow Sweeper: e.g. "[REDACTED_FINANCIAL_1] → Rp32,775 jt"
    const arrowRx = /(\[REDACTED_FINANCIAL_\d+\]\s*(?:→|->|menjadi|naik menjadi)\s*)(?:Rp\s*|IDR\s*|\$\s*)?[\d.,]+(?:\s*(?:jt|juta|k|million))?/gi;
    for (let turn of updatedTurns) {
      if (turn.content) {
        turn.content = turn.content.replace(arrowRx, "$1[REDACTED_PROJECTED_SALARY]");
      }
    }

    // Syntactic Increment Sweeper: e.g. "Kenaikan hanya:\nRp4,275 jt/bulan"
    const incRx = /(Kenaikan(?:\s+hanya|\s+sebesar)?\s*:\s*)(?:Rp\s*|IDR\s*|\$\s*)?[\d.,]+(?:\s*(?:jt|juta|k|million))?(?:\s*(?:per bulan|\/bulan))?/gi;
    for (let turn of updatedTurns) {
      if (turn.content) {
        turn.content = turn.content.replace(incRx, "$1[REDACTED_SALARY_INCREMENT]");
      }
    }

    return {
      anonymizedTurns: updatedTurns,
      mappings: Array.from(this.entityMap.entries()).map(([k, v]) => {
        const [cat, raw] = k.split("::");
        return { category: cat, original: raw, pseudonym: v };
      })
    };
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = ConsistentPseudonymizer;
}
